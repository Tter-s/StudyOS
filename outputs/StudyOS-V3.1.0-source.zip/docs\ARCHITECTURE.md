# 架构说明

> **V3.1 说明（2026-10-26）**：主路径已收敛为 `feature/today`、`feature/records`、简化财务、课表与我的；旧的 AI、学习中心、题库、排程等代码保留为归档兼容层，不再挂载导航。当前结构见 `README.md` 与 `docs/V3_1_RELEASE_NOTES.md`。

## 当前结构

采用单 Activity + MVVM + Repository，在 V0.1 边界上增量扩展课程、任务、学习中心、财务、自动排程、个人题库与可选 AI 规划：

```text
Compose Screen
    ↓ 收集 StateFlow / 发送用户操作
ViewModel
    ↓
Repository 接口
    ↓
Room / Preferences DataStore / Storage Access Framework
```

- `MainActivity` 只负责边到边与 Compose 内容。
- `StudyOSApplication` 持有 `AppContainer`。
- `AppContainer` 使用懒加载手动依赖注入；当前对象图很小，不引入 Hilt。
- `OfflineTaskRepository` 将任务 Room Entity 转为领域模型，作为首页任务数据源，并在事务内保存任务与学习会话，提供完成/取消完成、启停、延期、重排、周期系列删除和按日查询。
- `OfflineScheduleRepository` 汇总学期、课程规则、日期例外、一次性日程和作息表，并在写入前执行实例级冲突检测。
- `core/schedule` 中的纯 Kotlin 算法负责教学周、重复展开、跨日裁剪、区间合并、空闲补集和时区边界，不依赖 Android UI。
- `core/task` 中的状态机、校验、周期展开、任务冲突检测和日计划不依赖 Compose；课程、任务、休息由 `StudyDayPlanner` 统一合成。
- `OfflineLearningRepository` 负责科目、计时会话、习题、自控记录和学习目标，计时心跳、暂停与完成均在事务中更新。
- `core/learning` 的科目统计和自控趋势为纯 Kotlin 计算，不访问 UI 或 Android API。
- `LearningViewModel` 维护计时状态、前后台暂停、5 秒心跳、番茄钟到点结束、计时历史、习题和自控分析；应用生命周期观察位于根 Compose 层。
- `HomeViewModel` 组合当天任务、课程快照和本月财务汇总，首页与学习页复用同一套计划结果；财务读取失败只把预算卡降级为“未设置”，不阻断任务。
- `OfflineFinanceRepository` 负责财务分类、记账、月度预算和分类预算，写入前校验金额、分类与删除约束。
- `core/finance` 中的 `Money`、汇总/趋势计算、搜索、CSV、JSON 备份和提醒策略均为纯 Kotlin（JSON 使用 Android 自带的 `org.json`），不依赖 Compose。
- `FinanceViewModel` 管理选中月份、搜索/筛选、预算、分类、导出和提醒开关；`core/data/export/FinanceDocumentStore` 通过 `ContentResolver` 写用户选择的文件，不申请存储权限。
- `core/reminder` 中的 `WorkManagerBudgetReminderScheduler`、`BudgetReminderWorker` 和 `BudgetNotifier` 负责唯一每日任务、低频通知和关闭取消；提醒状态保存在 Preferences DataStore。
- `core/scheduling` 中的 `AutoScheduler`、`TaskScoring`、`SchedulingPreviewEditor` 和 `DailyPlanSummaryBuilder` 为纯 Kotlin 确定性逻辑：构建固定占用、评分排序、填充空闲段、生成预览、校验手工调整和提醒摘要，不访问 UI。
- `OfflineSchedulingRepository` 负责排程设置、科目偏好和原子计划保存；保存只替换候选任务的未锁定时段，保留锁定/进行中/已完成任务的数据。
- `SchedulingViewModel` 组合任务、课表、排程设置和科目偏好，在 `Dispatchers.Default` 生成预览，管理预览过期、锁定/调整/移除和确认保存；学习页新增“排程”标签。
- `WorkManagerPlanReminderScheduler`、`PlanReminderWorker` 和 `PlanReminderNotifier` 负责可选的每日计划提醒；Worker 只读取已保存任务，不运行排程引擎，也不修改任务。通知权限、WorkManager 重启恢复和系统延迟边界在 UI/文档中明确。
- `task_sessions.isLocked` 是手工锁定/手工调整的持久化标记；手工新建/改动会话和“延期一天”会锁定，自动排程只替换未锁定时段。
- `ScheduleViewModel` 管理教学周切换、课程 CRUD、调课/停课、一次性日程和作息保存状态。
- `core/importer` 的 `ScheduleOcrParser`、`ScheduleImportValidation`、`ScheduleImportAnalyzer` 和 `ScheduleImportFormat` 为纯 Kotlin：把 OCR 文字行解析为课程草稿、校验字段、按周次/单双周/跨日区间检测重复与冲突，不依赖 Compose 或 Android。
- `core/importer/image/ScheduleImageLoader` 负责从 ContentResolver 读取带大小上限的字节、解析 EXIF 方向、按预览/OCR 尺寸采样、旋转和归一化裁剪；只在图片边界处依赖 Android。
- `ScheduleImportService` 是识别方案的唯一接口；V0.7 的 `MlKitScheduleImportService` 使用随 APK 打包的中文 ML Kit 模型，本地生成 `OcrDocument`，再交给同一个纯解析器。云端视觉 AI 没有实现，也没有伪造按钮或网络调用。
- `ScheduleImportViewModel` 管理选图后的识别、草稿、节次时间表确认、学期设置、校验/冲突分析和原子导入；`ScheduleImportDialog` 是课表页的全屏模态流程（选图 → 裁剪/旋转 → 识别 → 预览表格 → 编辑/确认 → 完成）。
- `OfflineScheduleRepository.importCourses` 在一个 Room 事务中先对整批课程做校验与 `ScheduleImportAnalyzer` 查重，再逐条插入；任何一项失败抛出 `ScheduleImportConflictException`，不写入任何课程。
- `TaskViewModel` 管理日/周视图、选中日期、任务编辑结果、待安排列表、冲突标记和拖动顺序。
- V0.8 题库：`core/bank` 的 `ExerciseTextSplitter`、`ExerciseFormulaExtractor`、`ExerciseProblemParser`、`HeuristicProblemAnalyzer`、`ProblemDeduplicator`、`ExerciseTaskPlanner`、`ProblemDraftJson` 为纯 Kotlin（JSON 用 org.json）；`ProblemDocumentStore`/`PdfPageSource`/`ImagesPageSource` 在文件与渲染边界使用 Android API（PdfRenderer + PDFBox-Android 文本提取），`ExerciseOcrRecognizer` 复用打包的 ML Kit 模型。`ExerciseImportPipeline` 按页分批处理并把逐页状态与草稿 JSON 持久化到 Room，支持取消/恢复/失败重试。
- `OfflineProblemBankRepository` 在单个 Room 事务内完成用户确认题目的查重与写入；来源文档在仍有题目时拒绝删除。
- `ProblemBankViewModel`/`ProblemImportViewModel` 管理题库列表/筛选/详情编辑/生成任务和导入向导（选来源 → 分批处理 → 预览确认）；`ProblemBankHost` 挂在学习页「题库」标签。
- `ProblemAnalysisEngine` 是题目分析的独立接口（本地规则实现，AI 引擎后续接入），`ExercisePageSourceFactory` 是页面来源的独立接口；公式预览由打包的 KaTeX（MIT）在离线 WebView 中渲染，失败回退原文。
- V0.9 AI 规划：`core/ai` 中 `AiSnapshotBuilder`、`AiPromptBuilder`、`AiPlanParser`、`AiPlanConstraintChecker`、`AiCostCalculator`、`AiRequestHasher` 均为纯 Kotlin；`AiStudyDataSource`（`LocalAiStudyDataSource`）只读聚合任务/学习/题库/排程数据，**不包含财务**。
- `AiProvider` 是唯一的模型调用接口，`OpenAiCompatibleProvider` 基于自建 `AiHttpTransport`（HttpURLConnection），不引入 AI SDK；`AiPlanningService`（实现 `AiPlanCoordinator`）负责缓存、限额、离线检查、调用、Schema 校验、约束检查、用量与建议记录，AI 输出从不直接写业务库。
- `AiSettingsRepository`（DataStore，实现 `AiConfigStore`）保存非敏感配置；`KeystoreApiKeyStore` 用 Android Keystore AES-256-GCM 加密 API Key，`shared_prefs` 不在备份范围内。
- `AiPlannerViewModel` 管理数据快照、发送内容预览、隐私开关、手动生成、预览勾选与确认应用（仅更新任务预计用时）；`AiPlannerScreen` 挂在学习页「AI 规划」标签。`SettingsViewModel` 增加 AI 设置状态与「测试连接」，`AiSettingsCard` 位于「我的」页。
- V1.0 备份与导出：`core/backup` 的 `BackupCodec`（通用 SQL 快照/恢复 + 列兼容校验）、`BackupCreator`（ZIP + 原始文件）、`BackupRestorer`（校验、预览、事务恢复、提交后替换文件与恢复日志）、`CsvExport`（任务/计时/习题）与 `OfflineDataExportService`；`AppFileStore` 通过 SAF 读写用户选择的 ZIP/CSV，不申请存储权限。
- `feature/backup` 的 `DataBackupViewModel`/`DataBackupDialog` 挂在「我的」页；恢复必须先只读校验并二次确认，失败由底层保证回滚。
- 题库列表使用 `ProblemBankRepository.pageProblems`（SQL LIMIT/OFFSET + 聚合计数）分页；`ProblemBankViewModel` 维护已加载页并对外提供 `loadMore`，生成任务时单独查询全部命中项。
- 启动路径仅创建 `AppContainer`；PDFBox 资源在首次打开 PDF 来源时按需初始化。题库详情默认最多渲染 8 条公式预览，其余按需展开。
- `SettingsViewModel` 负责主题偏好读写。
- Navigation Compose 管理五个顶级目的地；底部导航使用 `launchSingleTop`、`saveState` 和 `restoreState`。

## 状态规则

- 加载中：显示真实进度指示。
- 空数据：显示未设置或暂无任务，不填 0 元、0 小时等容易被误认为真实统计的值。
- 错误：首页、学习中心和财务页提供重新订阅数据流的重试操作。
- 任务写入：状态机拒绝互相矛盾的结果；保存失败返回真实原因，不伪造成功。
- 计时：任何时刻最多一个活动计时；暂停/完成/后台切换通过事务提交，状态不为“运行中”时禁止继续累计。
- 分析：无计划时完成率返回空并用“暂无计划”展示，不把 0/0 伪装为 0%。
- 财务：没有预算时 `remainingFen` 为 null 并显示“未设置”；金额、分类和删除约束在仓库层再次校验，UI 不是唯一防线；写入文件失败显示真实错误，不伪报成功。
- 排程：生成只是预览，`保存` 才写库；生成中/保存中有独立状态，按钮禁用并显示进度。未安排任务和原因（无空闲/日上限/会话上限/无连续时段）始终保留，不伪装全部成功。
- 排程冲突：固定时段（锁定/进行中任务与课程、作息、其他任务）冲突单独提示；手工调整与固定/其他预览时段重叠时拒绝并说明原因。预览在任务、课表、设置或日期变化后标记过期并禁止保存。
- 排程锁：锁定时段是硬占用；自动保存只删除候选任务未锁定旧时段。手工调整/新建/延期会锁定，任务详情可显式锁定/解锁。
- 课表导入：OCR 结果只是内存中的草稿，预览前不写库；缺失必填字段、待确认、重复、冲突的行不可选中。节次时间表未确认或未设置学期时禁止导入。导入失败保留草稿并显示真实原因；成功后才清空草稿，原有课程不被修改。
- 课表导入失败：图片读取/解码失败、裁剪过小、OCR 失败、未识别到表头/课程、字段不完整、重复/冲突、事务写入失败都有明确状态；任何失败都不产生半批课程。图片预览会缩放，但裁剪使用归一化坐标应用到原图，旋转按 EXIF + 用户旋转的总角度应用。
- 计划提醒：默认关闭；开启后 WorkManager 每日检查，只读已保存计划；通知权限被拒绝时设置保留但明确提示不会弹出；关闭时取消唯一任务。
- 预算提醒：开关默认关闭；关闭时取消唯一周期任务；没有通知权限或系统通知关闭时不记录“已提醒”，也不会高频补发。
- 页面业务未实现：明确说明后续版本，不提供无效按钮。

## 时间、时区与金额

使用 `java.time.Clock`、`LocalDate`、`LocalTime` 与明确 `ZoneId`。学期配置保存课程使用的 IANA 时区；未设置学期时，一次性日程、作息和任务按设备当前时区解释。日期边界为当地自然日；数据库保存 `dateEpochDay`，避免把 epoch day 当作时间戳。课程、日程和任务会话的时间区间均为“含开始、不含结束”，结束分钟可超过 1440 表示跨日。重复计算使用 civil date 的 `plusDays`，DST gap/overlap 只在最终转换为 `Instant` 时按 zone rules 处理：重叠开始时取较早 offset，结束时取较晚 offset。

学习中心使用设备当前 IANA 时区：计时按开始时的当地日期归集；活跃时长用 `Instant` 计算，暂停时停止。运行中的计时每 5 秒把当前片段累加进 Room 并重置片段起点；应用 `ON_STOP` 立即暂停。异常终止后恢复只使用最后落盘累计值，不信任 `runningSince` 到重启之间的未知时间。首页仍主要在重新组合数据或重启后刷新日期。

财务模块以用户选择的 `LocalDate` 作为记账日期并保存 `dateEpochDay`；月份、周和趋势都只由该日期计算，不依赖记录创建时刻或设备当前时区。财务的“今天”、当前月份和剩余天数按设备本地时区计算，与课表使用学期时区的口径分开；首页预算卡使用设备日期，任务/课程日期仍使用学期时区。周趋势使用周一至周日并把首尾周裁剪到所选月份；月趋势使用 civil month 加减。预算提醒使用设备当前时区，在 09:00 左右安排检查，但 WorkManager 允许系统延迟。

自动排程使用课表的 IANA 时区（未设置学期时回退设备时区）确定“今天”和当前分钟；所有硬占用和自动学习块都用当地民用分钟表示，自动块限制在单个自然日内（结束分钟 ≤ 1440），不跨越午夜。跨日课程/作息/任务固定段由现有 `ScheduleEngine.visibleSegment`/`TaskSession.sessionsVisibleOn` 在两天的预览中拆分显示。今天已过去的分钟不会被排入；`now` 向上对齐到 5 分钟。任务截止日期只限制自动块不晚于该日期；逾期任务允许从今天起尽快安排。每日计划提醒的触发时间使用设备本地墙钟时间（WorkManager 延迟），而通知中“今天”的计划日期使用课表时区；两个口径在 README 中明确。

课表导入的裁剪是“旋转后的归一化矩形”，预览和 OCR 使用同一套坐标；OCR 先按总旋转角校正，再裁剪。节次到钟点的转换使用从图片左侧读取的时间，缺失时使用用户明确确认的节次时间表；该表只影响本次导入，不修改已有课程。EXIF 镜像（非 90° 旋转）暂不应用，常见截图不包含该情况。

金额统一以 `Long` 分表示。`core/finance/Money` 负责严格解析与格式化，数据库不保存浮点金额；预算、退款和趋势计算全部使用整数分。展示使用率时向下取整；占比需要显示比例时仅用整数除法/四舍五入，图表只为几何尺寸使用浮点数，不影响金额结果。

## 依赖注入演进

当前手动 DI 足够且可测试。若后续模块、Worker 和跨组件依赖明显增多，可评估引入 Hilt；不以预先复杂化为目标。

## 测试策略

- JVM：任务状态机/字段校验、周期展开、多会话拆分、任务与课程冲突、课程/任务/休息日计划、学习科目统计和自控日/周趋势，以及 V0.2 的重复规则、调停课、空闲补集和 DST；V0.5 金额解析/格式化、财务汇总/趋势/分类占比、搜索、CSV、预算提醒策略与首页预算状态；V0.6 排程评分、确定性排序、固定占用/缓冲/拆分、日上限、无空闲、跨日、截止边界、锁定冲突、极端任务量和预览编辑/校验，以及提醒时间计算和计划摘要。
- Robolectric：任务/课程/学习/财务/排程 Room DAO、`1→6`、`2→6` 迁移、计时心跳/暂停/恢复/补录/修正事务、财务 CRUD/预算/分类约束、排程设置/科目偏好、原子计划保存和锁保留、JSON 备份结构、预设科目/财务分类种子、文件数据库打开和 Compose/Navigation 冒烟测试。
- 课表导入 JVM：OCR 布局样例 7 门课程字段、无表头/无节次/缺教室/缺周次/多段周次/合并块拆分/全角字符/页脚噪声/边界节次等 11 项解析测试；字段校验、节次-钟点转换、重复/冲突（单双周、周次交集、跨日、周日晚跨周、批次内）13 项；图片旋转/裁剪/EXIF 映射/非法输入 5 项；导入仓库原子写入/整批回滚/无学期/重复 5 项；导入 ViewModel 识别/网格确认/学期/失败保留 9 项。
- 课表导入 Robolectric/Compose：预览表格状态/导入按钮与裁剪界面冒烟；从课表页打开导入流程；Room 迁移测试保持 v1→v6、v2→v6。
- 课表导入真机：相册 Photo Picker、旋转/裁剪手势、ML Kit 中文截图识别准确率、无网络识别、深色/小屏/大字体布局、升级安装和失败后原课表不变。
- 真机：安装、系统栏、返回手势、字体、主题、拖动排序、前后台计时暂停、小屏横向课表、系统文件选择器、通知权限、WorkManager 实际唤醒/重启恢复、每日计划通知送达、排程预览布局和手工调整验收。


## V2.0 增补

- **数据库**：Room v9（55 张表）；`MigrationsV8To9.kt` 只新增表/默认值列；`SyncTriggers` 在新建与迁移时安装；旧备份允许缺失新表并回填任务 `globalId`。
- **睡眠**：`SleepProtectionEngine` 纯 Kotlin，计算 night 绝对窗口、状态与冲突；`SleepRepository` 负责设置/特殊日期/记录/变更历史；`SchedulingInput.sleepIntervals` 与 `StudyDayPlanner` 把睡眠加入硬占用；`WorkManagerSleepModeScheduler` 单次链式提醒。
- **历史**：`HistoryRecorder` 与 `TaskEvent` 在业务事务内写入；`TaskSnapshotJson` 与 `TaskEventView` 供 UI；删除任务不级联历史。
- **词汇**：`Sm2Scheduler` 纯函数；`OfflineVocabularyRepository` 负责批次导入、每日上限、任务生成与复习记录；每日任务仍进入既有 TaskRepository/排程。
- **知识图谱**：`KnowledgeGraphEngine` 纯函数做环校验、前置闭包、分层布局与 AI 建议校验；`KnowledgeRepository` 负责种子、笔记/掌握度、题目链接和尝试信号。
- **习题/数学**：`ExerciseAbilityEngine` 纯函数；`OfflineExerciseRepository` 在事务内写尝试、档案、知识点掌握与历史；`OfflineMathHintRepository` 调用 `AiTaskService`，校验 Schema、记录提示/证明/错误报告，不直接写业务库。
- **报告**：`LearningFactBundle` 为只读事实集合；`WeeklyReportEngine`/`GrowthAnalyticsEngine` 纯 Kotlin；`OfflineReportRepository` 从 Room 聚合、写周报摘要、导出 PDF、调用统一 AI。AI 只接收聚合指标。
- **财务**：`FinanceForecastEngine` 纯函数（整数分）；`FinanceViewModel` 计算预测/异常/7/30 天/自定义区间；`FinanceForecastCards` 只做展示与标记操作。
- **考试目标**：`ExamReviewPlanner`/`GoalProgressCalculator` 纯函数；`OfflineExamGoalRepository` 生成待安排任务并记录历史；`ExamReminderWorker` 每天一次检查。
- **数据所有权/同步**：`SecureBackup.kt` 提供 AES-GCM 加密流与 JSON 导出/彻底删除；`LocalSyncService` 读触发器队列、基线、墓碑，增量导出加密同步包，导入前预览冲突；云端由 `SyncTransport` 抽象，未配置。
- **组件**：四个 `GlanceAppWidget` 直接读 Room；`WidgetUpdater` 在 Activity 前后台与 30 分钟周期刷新；无系统层高频轮询。
- **UI**：首页卡片顺序/显隐由 `HomeCardRepository` 持久化；学习中心新增标签；`MainActivity` 解析组件 Intent 的 destination/section 并交给 NavHost。
