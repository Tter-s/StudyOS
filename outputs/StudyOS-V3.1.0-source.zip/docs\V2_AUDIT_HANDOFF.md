# StudyOS V2.0 审计交接文档

> 当前工程已发布 V3.0.0（versionCode 30）；V3 的默认 DeepSeek、恢复哨兵、报告窗口化与签名说明见 `docs/V3_RELEASE_NOTES.md`。

版本：`2.0.0`（versionCode 20），数据库 v9。
生成日期：2026-10-25。
用途：交给后续负责漏洞排查、代码审计、测试补充与真机验收的 AI/工程团队。

> 本文档优先列出真实实现、已知风险和未验证项，不把“已写代码”等同于“已真机验证”。自动化结果见 README「本轮验证记录」与 `docs/V2_RELEASE_NOTES.md`。

## 1. 全部新增模块

### 1.1 数据与基础设施

| 模块 | 主要文件 | 说明 |
| --- | --- | --- |
| Room v9 | `core/data/local/StudyOSDatabase.kt`、`StudyOSMigrations.kt`、`MigrationsV8To9.kt`、`V2Entities.kt`、`V2Daos.kt` | 55 张表；v8→v9 真实迁移；27 张新表；同步触发器 |
| 任务历史 | `core/history/TaskHistory.kt`、`HistoryDao`、`TaskHistoryDialog.kt` | 事件模型、快照、推导、分析、查看/永久删除 |
| 睡眠 | `core/sleep/*`、`SleepRepository.kt`、`feature/sleep/*`、`SleepModeReminders.kt` | 作息/覆盖/午休/缓冲、跨午夜、状态、冲突、睡前模式提醒 |
| 数据所有权 | `core/ownership/SecureBackup.kt`、`core/backup/*`、`feature/data/*` | 加密 ZIP、JSON 导出、彻底删除 |
| 统一 AI | `core/ai/AiTaskService.kt`、`AiModels.kt`、`AiPromptBuilder.kt`、`OpenAiCompatibleProvider.kt`、`KeystoreApiKeyStore` | 文本任务、缓存、限额、费用、JSON 校验、重试 |
| 本地同步 | `core/sync/LocalSyncService.kt`、`SyncModels.kt`、`SyncTriggers.kt`、`feature/data/*` | 触发器、增量包、基线、墓碑、冲突、SAF、传输适配 |
| 首页卡片 | `HomeCardRepository.kt`、`HomeCards.kt`、`HomeViewModel.kt` | 卡片显隐/排序、下一节课/当前任务/睡眠/考试/词汇/习题卡 |
| 桌面组件 | `widget/StudyOSWidgets.kt`、`res/xml/widget_*_info.xml`、`res/layout/widget_loading.xml` | 四类 Glance 组件与 30 分钟兜底刷新 |

### 1.2 学习模块

| 模块 | 主要文件 | 说明 |
| --- | --- | --- |
| 英语词汇 | `core/vocabulary/*`、`VocabularyRepository.kt`、`feature/vocabulary/*` | CSV/TSV、SM-2、每日上限、背诵/复习、统计、任务生成 |
| 知识图谱 | `core/knowledge/*`、`KnowledgeRepository.kt`、`feature/knowledge/*` | DAG、种子、AI 建议校验、掌握度、题目关联、Canvas 图 |
| 数学助手 | `core/math/*`、`MathHintRepository.kt`、`ExerciseRepository.kt`、`feature/math/*` | 五级提示、证明检查/保存、尝试记录、难度档案/推荐 |
| 周报/成长 | `core/report/*`、`core/growth/*`、`ReportRepository.kt`、`feature/report/*` | 事实采集、离线统计、指标定义、PDF、AI 分区、跨学期 |
| 考试/目标 | `core/exam/*`、`ExamGoalRepository.kt`、`feature/exam/*`、`ExamReminders.kt` | 倒计时、复习任务、里程碑、考试提醒 |
| 财务 V2 | `core/finance/FinanceForecast.kt`、`FinanceForecastCards.kt`、`FinanceViewModel.kt` | 预测、7/30/自定义区间、异常、正常开支标记、建议 |
| 任务 V2 | `TaskRepository.kt`、`TaskViewModel.kt`、`StudyDayPlanner.kt`、`AutoScheduler.kt` | 历史事件、睡眠硬占用、版本/全局 ID、计划任务来源 |

### 1.3 UI/导航

- 学习中心新增：词汇、图谱、数学助手、周报成长、考试目标。
- 首页改为可配置卡片 + 时间轴 + 今日任务；显示学期/教学周。
- 我的页新增：睡眠与作息、数据与同步、首页卡片显隐/排序。
- 桌面组件点击携带 `EXTRA_DESTINATION`/`EXTRA_SECTION`，`MainActivity` 在 `onCreate`/`onNewIntent` 应用。
- `ProfileScreen` 同时保留普通备份/CSV 对话框。

## 2. 关键业务逻辑

### 2.1 睡眠硬约束

- `SleepProtectionEngine.effectiveForNight` 优先级：特殊日期 > 考试周 > 周末（周五/周六夜）> 工作日。
- `nightInterval` 用绝对分钟；支持床头时间在午夜后且睡前缓冲跨到前一天。
- `intervalsOn(date)` 检查 `date-1/date/date+1` 三个夜晚并裁剪到自然日，避免漏掉 23:40–24:00 的睡前缓冲。
- `statusAt` 用绝对分钟判断 `WIND_DOWN`/`ASLEEP`，修正凌晨入睡时把睡眠尾段误判为睡前缓冲的问题。
- 排程：`SchedulingInput.sleepIntervals` → `AutoScheduler.buildDay` 作为 `ROUTINE` 硬占用；`StudyDayPlanner` 也加入睡眠实例，首页/任务页空闲时间扣除睡眠。
- 手工任务保存：不会静默覆盖；任务页列出与睡眠重叠的会话。自动排程绝不排入。
- 睡前模式：`WorkManagerSleepModeScheduler` 只排下一次提醒；`SleepModeWorker` 只在实际睡前缓冲开始后 15 分钟内发送，避免延迟到凌晨骚扰；不操作系统 DND。

### 2.2 任务历史

- 写入点：`OfflineTaskRepository` 创建/编辑/完成/重开/开始/暂停/延期/删除/锁定；`OfflineSchedulingRepository.applyPlan` 自动排程；`OfflineExerciseRepository.submitAttempt` 习题尝试；`OfflineMathHintRepository` 提示；`OfflineVocabularyRepository` 复习；睡眠/考试/目标/知识/财务也有对应事件类型。
- 同事务：业务写入与 `task_events` 在一个 Room 事务中；删除任务不会级联删除历史（无外键）。
- 快照使用 `TaskSnapshotJson`，含任务关键字段与会话数/分钟；新增字段不会让旧历史失效。
- 用户可在任务详情「查看完整任务历史」中永久删除该任务历史。

### 2.3 数据所有权/加密

- 普通 ZIP：`BackupCreator`/`BackupRestorer`；v1.0 备份缺失新表允许恢复；恢复旧备份时临时移除 `globalId` 索引、回填、重建；恢复后清空同步状态。
- 加密备份：`EncryptedBackupCrypto` 格式 `STUDYOS-ENC-1 | salt | iv | iterations | AES-256-GCM ciphertext`；PBKDF2-HMAC-SHA256 120k；随机盐/IV；口令只在调用栈。
- JSON 导出：表名+行对象+版本+附件清单+偏好（AI 配置去密钥）；不提供反向导入。
- 彻底删除：业务表/附件/AI 分析/同步状态；重新写入预设科目与财务分类；可选清 API Key 与 AI 设置；保留主题等应用偏好。

### 2.4 统一 AI

- V0.9 的 `AiPlanningService` 保留；V2 新增 `AiTaskService` 供数学提示/证明/周报/成长/知识关联使用。
- 配置、Key、离线、每日次数/费用上限统一检查；输出先记用量再校验；缓存只存通过校验的内容；失败不写业务库。
- 数学提示：`MathHintPromptBuilder` 按 Level 生成不同规则；解析校验 `level` 与请求一致；Level 5 必须显式确认；提示记录写 `exercise_hint_records` 与历史；缓存键含题目、公式、知识点、用户思路、等级和模型。
- 周报/成长：发送聚合数据，不含财务流水、睡眠原始时刻、任务标题；要求 JSON 分区；UI 区分数据/推测/建议。
- 知识关联：AI 输出名称映射到已存在节点，再经 DAG/重复/环校验；用户确认后写入。

### 2.5 同步

- 触发器：`study_tasks`、`finance_transactions`、`vocabulary_words`、`knowledge_nodes`、`exams`、`long_term_goals` 的插入/更新/删除写入 `sync_operations`；删除写 `sync_tombstones`。
- 导出：只包含从未导出或哈希与独立导出水位不同的对象（增量），加墓碑；AES-GCM 加密。导出不改变冲突基线。
- 导入预览：以 `sync_baselines` 判断双方是否自上次同步后修改；双方都改 → 冲突，由用户选择本地/同步包；删除与编辑冲突也进入冲突；未处理冲突保留本地。
- 应用：`applyPreview` 在单事务中更新任务（含时段）、财务（解析/创建分类）、词汇（按 normalizedWord 合并）、知识（节点+缺失依赖）、考试、目标（含里程碑）；删除走墓碑。
- 云端：`SyncTransport` 接口 + `UnconfiguredCloudSyncTransport` 明确未配置。

### 2.6 报告与成长口径

- 周报事实来自 Room：任务会话、计时、习题尝试/提示、词汇复习、睡眠记录、自控、财务、目标。
- 关键口径：
  - 计划完成率 = 已安排完成数 / 已安排任务总数；无安排 → 数据不足。
  - 独立完成率 = 独立尝试数 / 总尝试数；独立由“未使用提示且用户/系统判定独立”约束。
  - 计划偏差 = (计时分钟 − 已安排计划分钟) / 计划分钟。
  - 睡眠只统计有实际入睡/起床记录的天数；<3 天不生成规律结论。
  - 相关性不代表因果；不预测成绩/排名。
- 跨学期：9–1 月秋季、2–7 月春季，8 月不计入；明确是应用内观察口径。
- AI 只接收聚合值。

### 2.7 习题难度

- `ExerciseAbilityEngine`：个人难度 = 估计难度 + 失败/提示/超时 − 独立率；掌握度 = 独立率 0.5 + 无提示 0.25 + 用时效率 0.15 + 成功率 0.1；能力样本阈值 3 次。
- 推荐在错题/变式/挑战/基础之间分散，gap>0.6 施加惩罚，避免持续超纲。
- 用时修正：≥2 次实际用时中位数与预计偏差 ≥30% 时建议 5 分钟取整。
- 多次失败（≥2）才查询知识图谱前置知识给出复习建议。

## 3. 数据库迁移路径

1. 新装：Room 创建 v9，`onCreate` 写入预设科目/财务分类并安装同步触发器。
2. V1.0（v8）升级：`Migration(8,9)`：
   - `study_tasks` 加 4 列并回填 `globalId='task-'||id`；建非唯一索引。
   - `finance_transactions` 加 2 列。
   - 创建 27 张新表、索引与触发器。
3. 更早版本：v1→2→…→8→9，测试覆盖 v1/v2/v6 升级。
4. 备份恢复：`BackupCodec` 按当前 Schema 列求交集；旧备份缺表按空表；恢复前校验版本/必填列/文件；单事务导入并核对行数；失败回滚；提交前写 `.restore_journal`，并在同一事务写入 `sync_state` 恢复哨兵，进程中断后可判断数据库是否已提交再完成/回滚文件替换。
5. 回滚：数据库无降级迁移。回退应用需卸载 V2.0，安装 V1.0 后用 V1.0 备份恢复；Debug/Release 签名不同，不能覆盖升级。

## 4. API 配置位置

- UI：`feature/profile/AiSettingsCard.kt` + `SettingsViewModel`。
- 非敏感配置：`core/data/preferences/AiSettingsRepository.kt`（DataStore `ai_settings`）。
- API Key：`core/ai/security/ApiKeyStore.kt`（Android Keystore，AES-256-GCM；独立 SharedPreferences，不进入备份/导出/日志）。
- 网络：`core/ai/network/OpenAiCompatibleProvider.kt` + `AiHttpTransport.kt`；仅 `INTERNET` 权限。
- 统一任务：`core/ai/AiTaskService.kt`；规划旧链路：`AiPlanningService.kt`。
- 费用/额度：`AiCostCalculator.kt`、`AiUsageDailyEntity`；每日上限在配置与调用前双重检查；`AiRequestGate` 把规划服务与统一任务服务的检查/调用/记账串行化，避免并发突破额度。
- 云端同步配置：目前没有；`SyncTransport`/`UnconfiguredCloudSyncTransport` 在 `core/sync/SyncModels.kt`，UI 明确显示未配置。

## 5. 已知风险

### 高优先级

1. **同步对象身份**：按 `objectType + 本地 ID` 合并；不同设备各自新建对象可能 ID 碰撞；`study_tasks.globalId` 已存在但当前同步未用它作为主键。大量跨设备同步前需修复为全局 ID/映射表。
2. **同步范围**：只覆盖任务、财务、词汇、知识、考试、目标；课表/作息、计时、习题明细、完整预算/偏好未进入增量同步，错误地假设“已全部同步”会导致数据缺失。UI 已选择同步范围，但产品文案需继续强调。
3. **事务边界**：部分跨仓库调用（`ExerciseRepository` 内调用 `ProblemBankRepository.updateProblem`/`KnowledgeRepository.applyAttemptSignal`）使用 Room 嵌套事务；需审计嵌套事务失败时的回滚范围。
4. **报告范围读取**：`ReportRepository.collectFacts()` 已按周/最近 24 个月窗口读取计时、尝试、提示、词汇复习、睡眠、自控与财务明细；任务、词汇、目标仍全量用于积压/总量统计，超大长期数据仍有 OOM 风险。
5. **加密口令处理**：`EncryptedBackupCrypto`/`AppSecureBackupService` 内部把 `CharArray` 转 `String`（不可清零）；`AiTaskService`/配置 Key 不写日志，但需审计异常堆栈是否可能带出敏感内容。
6. **数据库触发器**：`SyncTriggers` 在新建/升级时安装；若未来迁移重建表需重新安装；备份恢复会清空同步状态。需审计触发器在批量恢复/删除/级联场景下的队列噪音。
7. **手工任务与睡眠**：手工保存可以越过睡眠，仅显示冲突提示，不是强制阻断；是否满足“默认不允许”需产品确认。

### 中优先级

8. **WorkManager 提醒**：非精确闹钟；考试/睡前可能延迟或错过；没有通知渠道分组设置页；权限撤销后静默失败（界面无实时状态）。
9. **桌面组件刷新**：30 分钟 + 前后台；计时组件不是逐秒更新；系统更新时钟/时区变化未专项处理。
10. **PDF 中文排版**：依赖系统字体回退；未真机验证；导出内存使用未测。
11. **AI 成本/取消**：底层 HttpURLConnection 取消仅在协程取消/超时生效；调用没有服务端流式；费用为估算；缓存键包含模型和提示版本但不含价格。
12. **AI 输出真实性**：数学证明/周报推测可能错误；已标注不确定性，但不能替代严格验证。
13. **知识图谱种子**：初次插入 40 个节点和依赖；节点全部被删除后会重新写入种子（删除部分节点不会）；AI 建议只按名称匹配、跨科目同义词未处理。
14. **词汇**：未提供逐行导入预览；CSV 大文件读入内存；无发音音频；`averageReviewMinutesPerDay` 实为平均反应时间，不是每日学习时间。
15. **财务异常/预测**：基于类目历史均值/方差，样本少或无预算时行为不同；固定支出用分类预算合计近似；异常标记无历史事件（仅更新字段）。
16. **首页卡片**：仅上/下移动，非拖拽；排序写入需测试并发保存。
17. **报告 AI 输入**：周报只排除财务/睡眠原始记录，仍包含聚合学习数据；需隐私文案持续一致。

### 低优先级

18. `LocalSyncService` 的 `summary` 对缺失 row 的兜底、哈希异常处理；`sync_operations.payloadHash` 由触发器写空字符串，仅用于队列展示，不用于冲突判断。
19. 大量 UI 中 `remember`/状态与数字格式化风格不完全统一；部分标签/说明可按真机阅读体验再调整。
20. Widget 文案/尺寸/深色适配未视觉验收；`widget_loading.xml` 是简单占位。

## 6. 未验证功能

以下仅通过编译/单元测试或代码审查，**未在设备/模拟器实测**：

- 四类桌面小组件添加、调整大小、深浅色、重启/更新、点击跳转、空状态。
- 通知权限允许/拒绝、考试提醒每日一次、睡前模式通知、WorkManager 延迟/重启恢复、渠道设置。
- PDF 周报中文渲染、分页、字体缩放、分享/保存。
- 加密备份创建/预览/恢复、错误口令、存储不足、大附件、恢复中断回滚。
- JSON 导出内容与附件清单、彻底删除后重启。
- 两台设备加密同步包交换、增量、冲突选择、删除墓碑、ID 冲突。
- 首页卡片显隐/排序在真实数据与旋转/进程重建下。
- 睡眠跨午夜/凌晨入睡在排程页/任务页/首页的实际显示；与课程冲突提示；大字体/横屏。
- 知识图谱 Canvas 点击、缩放/滚动、节点编辑、AI 建议应用。
- 数学提示所有等级、LaTeX 公式矩阵/积分/分段、证明保存/报告错误。
- 词汇 CSV 导入、复习调度、任务生成与排程联动。
- 考试复习任务生成与首页倒计时、目标进度。
- 深色主题、系统字体缩放、横竖屏、无障碍所有新页面。
- 从 V1.0 真机升级安装/回退；Debug→Release 签名切换。

## 7. 建议优先审查的代码

1. `core/data/local/MigrationsV8To9.kt`、`StudyOSDatabase.kt`、`BackupArchive.kt`：迁移/回填/索引/触发器/旧备份兼容。
2. `core/sync/LocalSyncService.kt`、`SyncTriggers.kt`：身份、基线、冲突、事务、SQL 注入/路径安全。
3. `core/ownership/SecureBackup.kt`：加密参数/口令生命周期/GCM 错误、JSON 导出与彻底删除。
4. `core/sleep/SleepProtectionEngine.kt`、`SleepRepository.kt`、`SleepModeReminders.kt`：绝对分钟、跨午夜、WorkManager 调度、通知窗口。
5. `core/ai/AiTaskService.kt`、`AiPlanningService.kt`、`OpenAiCompatibleProvider.kt`、`KeystoreApiKeyStore`：密钥、日志、重试、额度、缓存、取消。
6. `core/ai/AiTaskService` 调用方：`MathHintRepository.kt`、`ReportRepository.kt`、`KnowledgeViewModel.kt`：Schema 校验、用户确认、隐私数据范围。
7. `core/data/repository/ExerciseRepository.kt`、`TaskRepository.kt`、`SchedulingRepository.kt`：嵌套事务、历史事件、修订/全局 ID、睡眠/冲突。
8. `core/finance/FinanceForecast.kt`、`FinanceViewModel.kt`：整数金额、异常阈值、预算建议措辞。
9. `ReportRepository.kt`、`WeeklyReportEngine.kt`、`GrowthAnalyticsEngine.kt`：全量读取、口径、空值/数据不足、跨学期边界。
10. `widget/StudyOSWidgets.kt`、`MainActivity.kt`：组件数据读取、Intent/导航、刷新频率、权限/空状态。
11. `StudyOSApplication.kt`、`MainActivity.kt`：WorkManager 初始化容错、周期任务、`onNewIntent` 重建。
12. 新页面 ViewModel/Screen 的协程异常与重复提交（词汇、图谱、数学、报告、考试、睡眠、数据工具）。

## 8. 构建与测试命令

```bat
set JAVA_HOME=D:\jdk17
gradlew.bat :app:compileDebugKotlin
gradlew.bat :app:testDebugUnitTest
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.sleep.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.vocabulary.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.knowledge.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.finance.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.report.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.data.local.StudyOSDatabaseMigrationTest"
gradlew.bat :app:lintDebug
gradlew.bat :app:assembleDebug
gradlew.bat :app:assembleRelease
```

当前实际结果：497 项测试通过，0 失败、0 跳过；lint 0 errors、40 warnings；Debug/Release 均构建成功。APK 签名校验通过。

## 9. 需要真机验证的功能

1. **桌面组件**：四个组件添加/调整/深色/重启后更新/点击跳转/空状态。
2. **通知**：POST_NOTIFICATIONS 允许/拒绝、考试提醒、睡前模式、WorkManager 延迟与重启恢复、省电模式。
3. **升级**：从 V1.0 Debug/Release 升级保留数据、旧备份恢复、回退步骤。
4. **加密备份**：创建/预览/恢复、错误口令、附件、存储不足、事务回滚。
5. **同步包**：两台设备交换、增量、冲突选择、删除墓碑、ID 冲突。
6. **PDF**：中文、分页、大字体、深色（报告为白底 PDF）。
7. **睡眠/任务**：跨午夜与凌晨入睡的显示和排程、课程冲突、手工越界提示。
8. **数学助手**：所有等级、跳级确认、完整证明、LaTeX 矩阵/积分/分段、证明检查。
9. **知识图谱**：Canvas 点击/滚动、大图谱、编辑/AI 建议。
10. **词汇**：CSV 文件选择、中文表头、重复、复习、生成任务。
11. **报告/成长**：大字体、横屏、长列表、PDF 导出。
12. **财务**：预测、异常标记、自定义区间、金额边界。
13. **视觉/无障碍**：首页卡片顺序、学习中心横向标签、我的页新入口、深色、字体缩放。

## 10. 可能存在的性能瓶颈

1. `ReportRepository.collectFacts()` 已窗口化明细，但任务/词汇/目标仍全量；超大长期数据的内存和加载时间仍会增长。
2. `ExerciseRepository.recommendations()` 读取全部题库摘要 + 最近 500 个档案 + 全部知识点关联；大题库需分页/索引优化。
3. `KnowledgeRepository.ensureSeeded()` 每次 graph flow 订阅都会检查节点并尝试同步题目链接（`INSERT OR IGNORE`）；节点/题目多时有重复查询。
4. `MathAssistantViewModel.openProblem` 每次打开题目加载尝试/档案/提示/保存证明；频繁切换题目会产生多次查询。
5. `VocabularyViewModel.refresh()` 读取 50 词 + 总数 + 词表 + 统计（最近 500 复习）；词库大时统计较慢。
6. 首页在每次数据变化时组合多个 Flow，并可能调用 `dueReviewProblemIds(50)` 统计习题；大题库下可优化为 SQL COUNT/Flow。
7. 桌面组件每次刷新四类组件、多个 Room 查询与 Flow first；30 分钟周期 + 前后台触发，正常，但低端设备可评估按需刷新。
8. 加密备份/同步包全量 ZIP 或 JSON 解析在内存中完成；大题库附件/大 JSON 可能内存峰值高。
9. 报告/成长趋势仍使用内存列表计算，未做 SQL 分组聚合/预聚合表；长期数据建议继续优化。
10. PDF 逐行绘制/换行在单页内存中完成；超长周报（多周/大量科目）可能耗时。

## 11. 交接建议

- 先执行全量测试与迁移测试，再按第 7 节顺序审计高危数据路径。
- 修复同步身份前，明确把“本地加密同步包”标记为实验性/单主设备优先，避免用户误以为是完整多端同步。
- 为报告/推荐增加 SQL 聚合/预聚合与性能测试（明细读取已按窗口缩小）。
- 真机优先验证通知、组件、加密恢复、PDF 与升级回退。
- 若接入云端，必须保留离线模式、端到端/客户端加密、密钥恢复限制说明，并禁止伪造同步成功。
- 任何 AI 新功能必须继续走 `AiTaskService`/Schema 校验/用户确认/本地约束，禁止直接写业务库。

