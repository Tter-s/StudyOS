# 知序 StudyOS V2.0 项目交接文档

> 当前工程已发布 V3.0.0（versionCode 30）；V2.0 的功能与数据库 v9 保持不变，V3 的默认 DeepSeek、签名与修复见 `docs/V3_RELEASE_NOTES.md`。

- 交接版本：`2.0.0`（versionCode 20）
- 数据库版本：9（55 张表）
- 交接日期：2026-10-26
- 代码位置：`D:/studyOS`
- 适用读者：接手开发、测试、审计或后续 AI 开发团队的工程师

> 本文件是“如何接手这个项目”的实用说明。漏洞、风险与建议优先审查的代码清单另见 `docs/V2_AUDIT_HANDOFF.md`；版本功能与验证记录见 `docs/V2_RELEASE_NOTES.md` 与 `../README.md`。

## 1. 一句话现状

项目已从 V1.0 完成 V2.0 功能开发，能够编译、运行、生成 Debug/Release APK；核心业务逻辑与数据库迁移有 497 项自动化测试覆盖。**尚未在模拟器或真机上做系统级验收**，因此桌面组件、通知、PDF、加密备份/同步、深色/大字体视觉和升级安装仍属于“已实现、待真机验证”。

## 2. 产物

| 内容 | 路径 |
| --- | --- |
| Debug APK | `outputs/StudyOS-V2.0.0-debug.apk` |
| 签名 Release APK | `outputs/StudyOS-V2.0.0-release.apk` |
| V1.0 回退 APK | `outputs/StudyOS-V1.0.0-debug.apk`、`-release.apk` |
| 版本更新说明 | `docs/V2_RELEASE_NOTES.md` |
| 审计交接 | `docs/V2_AUDIT_HANDOFF.md` |
| 工程说明 | `README.md` |
| 数据库 Schema | `app/schemas/com.zhixu.studyos.core.data.local.StudyOSDatabase/9.json` |
| 签名材料 | `.signing/studyos-release.jks` + `keystore.properties`（已 gitignore，需离线备份） |

Debug 与 Release 包名相同但签名不同，**不能互相覆盖安装**。

## 3. 快速开始

### 3.1 环境

- JDK 17 或 21（本机可用 `D:/jdk17` 或 `C:/Users/Tter/.workbuddy/binaries/jdk/jdk-21.0.12.1+1`）。
- Android SDK Platform 35；本机 `local.properties` 指向 `D:/Android/Sdk`。
- Gradle Wrapper 8.9；AGP 8.7.3；Kotlin 2.0.21。
- 推荐 Android Studio Ladybug 或更新版本。

### 3.2 构建、测试、Lint

```bat
set JAVA_HOME=D:\jdk17
gradlew.bat :app:compileDebugKotlin
gradlew.bat :app:testDebugUnitTest
gradlew.bat :app:lintDebug
gradlew.bat :app:assembleDebug
gradlew.bat :app:assembleRelease
```

当前实际结果：

- 编译成功。
- **497 项测试通过，0 失败、0 跳过**。
- **Lint 0 errors、40 warnings**（依赖版本、target SDK、少量布局属性/装箱建议）。
- Debug/Release 构建成功；`apksigner verify` 通过。

### 3.3 安装

```bat
adb devices
adb install -r outputs\StudyOS-V2.0.0-debug.apk
```

当前 `adb devices` 无设备。建议先连接一台 Android 8.0+ 真机，再做第 7 节的验收清单。

## 4. 架构与技术栈

```text
Compose Screen
  ↓ StateFlow / 用户操作
ViewModel
  ↓
Repository 接口
  ↓
Room / Preferences DataStore / SAF 文件 / WorkManager
```

- Kotlin、Jetpack Compose、Material 3、单 Activity。
- MVVM + Repository + 手动依赖注入（`di/AppContainer.kt`）。
- Room 2.6.1、Preferences DataStore、Navigation Compose、WorkManager 2.10、Glance 1.1.1。
- 金额统一 `Long` 分；日期用 `dateEpochDay`；时间用当地分钟；时区见课表学期设置。
- 核心算法（排程、睡眠、SM-2、知识图谱、能力估计、周报、财务预测、加密）都是纯 Kotlin，便于单元测试。

### 4.1 关键入口

| 入口 | 文件 |
| --- | --- |
| 应用/依赖容器 | `StudyOSApplication.kt`、`di/AppContainer.kt` |
| 主界面/导航 | `MainActivity.kt`、`navigation/StudyOSApp.kt`、`StudyOSNavHost.kt` |
| 数据库/迁移 | `core/data/local/StudyOSDatabase.kt`、`MigrationsV8To9.kt` |
| 首页 | `feature/home/HomeViewModel.kt`、`HomeScreen.kt`、`HomeCards.kt` |
| 学习中心 | `feature/study/LearningCenterScreen.kt` |
| 词汇 | `core/vocabulary/*`、`core/data/repository/VocabularyRepository.kt`、`feature/vocabulary/*` |
| 知识图谱 | `core/knowledge/*`、`KnowledgeRepository.kt`、`feature/knowledge/*` |
| 数学助手 | `core/math/*`、`MathHintRepository.kt`、`ExerciseRepository.kt`、`feature/math/*` |
| 周报/成长 | `core/report/*`、`core/growth/*`、`ReportRepository.kt`、`feature/report/*` |
| 考试/目标 | `core/exam/*`、`ExamGoalRepository.kt`、`feature/exam/*` |
| 睡眠 | `core/sleep/*`、`SleepRepository.kt`、`feature/sleep/*` |
| 数据/备份/同步 | `core/ownership/*`、`core/sync/*`、`core/backup/*`、`feature/data/*` |
| 桌面组件 | `widget/StudyOSWidgets.kt`、`res/xml/widget_*_info.xml` |
| AI | `core/ai/*`、`core/ai/security/ApiKeyStore.kt` |
| 提醒 | `core/reminder/*` |

## 5. 已实现模块

### 5.1 基础与既有功能

课程表/学期/教学周/单双周/调停课、任务与会话、离线自动排程、学习计时、手工习题、自控、财务、题库、AI 规划、完整备份/恢复、CSV 导出。V1.0 的既有功能保留。

### 5.2 V2.0 新增

1. **数据库 v9**：27 张新表；旧表只加默认值列；v1/v2/v6→v9 迁移测试；旧备份兼容；同步触发器。
2. **睡眠保护**：工作日/周末/考试周/特殊日期、最早起床/最晚睡觉/睡前缓冲/午休、跨午夜、首页/任务页/排程硬占用、冲突提示、睡前模式提醒。
3. **任务历史**：创建/编辑/排程/开始/暂停/延期/完成/重开/删除/锁定/AI 建议/习题提示等事件；前后快照、来源、原因；不随任务删除级联；可明确永久删除。
4. **数据所有权**：版本化 JSON 导出、AES-256-GCM 加密备份、恢复预览/事务回滚、彻底删除（可选清 API Key）。
5. **桌面组件**：今日任务、下一节课、学习计时、今日概览；响应式、深浅色、点击跳转、空状态；低频刷新。
6. **英语词汇**：CSV/TSV、SM-2、每日上限、积压、词汇任务、统计。
7. **知识图谱**：可编辑 DAG、种子图谱、题目关联、掌握度、AI 建议校验、多次失败复习建议。
8. **周报/成长**：离线统计、指标定义、数据不足、趋势、跨学期、PDF、AI 数据/推测/建议分区。
9. **数学助手**：五级提示、逐级解锁/跳级确认、完整参考证明确认、证明草稿/保存/检查/报告、LaTeX、个人难度/推荐。
10. **财务预测**：月底余额/总支出/风险、7/30 天与自定义区间、异常消费、正常支出标记、中性建议。
11. **考试/长期目标**：倒计时、每日提醒、复习任务、里程碑权重进度。
12. **本地同步**：触发器修改队列、删除墓碑、增量加密同步包、基线冲突检测、用户选择；云端未配置。
13. **统一 AI 服务**：`AiTaskService` 统一额度/费用/缓存/校验/重试/取消；AI 不直接写业务库。

## 6. 数据与迁移

### 6.1 版本

- 当前数据库 **v9**，共 55 张表。
- Schema 导出：`app/schemas/.../9.json`。
- 迁移链：`MIGRATION_1_2 … MIGRATION_8_9`，不使用破坏性迁移。

### 6.2 v8→v9 做了什么

- `study_tasks`：新增 `globalId`（回填 `task-<id>`）、`revision`、`sourceType`、`sourceId`。
- `finance_transactions`：新增 `revision`、`isExpectedExpense`。
- 新增 27 张表：历史、睡眠、词汇、知识图谱、考试/目标、习题尝试/提示/能力、AI 分析、周报、同步、首页卡片。
- 安装同步触发器（任务/财务/词汇/知识/考试/目标）。
- 从备份恢复时清理同步队列/基线/墓碑，并临时重建任务 `globalId` 索引。

### 6.3 升级/回退

- 同签名 V1.0 → V2.0 可直接覆盖安装，数据库自动迁移。
- V2.0 → V1.0 不支持数据库降级：卸载 V2.0、安装 V1.0、用 V1.0 之前的备份恢复；V2.0 加密备份 V1.0 读不了。
- 备份前先确认 `.signing` 与 `keystore.properties` 存在；丢失密钥将无法发布同签名升级包。

## 7. 接手第一天建议做什么

1. 执行全量测试、lint、Debug/Release 构建，确认结果与本文一致。
2. 连接真机安装 `outputs/StudyOS-V2.0.0-release.apk`。
3. 从 V1.0 覆盖升级（保留数据）并核对任务/课程/财务/题库；查看数据库版本。
4. 按 `README.md` 的「V2.0 手动验收清单」逐项验收：
   - 睡眠跨午夜/凌晨入睡、冲突提示；
   - 任务历史、词汇复习、知识图谱、数学提示；
   - 周报/成长、财务预测、考试目标；
   - 加密备份/恢复、JSON 导出、同步包冲突；
   - 四个桌面组件、考试提醒、睡前模式；
   - 深色/大字体/横屏。
5. 先不要做破坏性数据库迁移；任何 Schema 变更必须新增 Migration + 导出 Schema + 迁移测试。
6. 把真机发现的问题记录到缺陷列表，再按第 9 节优先级修复。

## 8. 配置与外部依赖

### 8.1 AI

- 位置：「我的」→「AI 设置」。
- 需要：OpenAI 兼容服务地址、模型、API Key、启用开关；可选 Token 单价与每日额度。
- API Key 使用 Android Keystore AES-256-GCM 加密，不进入 DataStore/数据库/日志/普通备份/JSON 导出。
- 支持文本生成与 JSON 输出；**不支持图片理解**。未配置时 AI 按钮明确报错，本地功能不受影响。
- AI 输出在缓存前做 Schema 校验；数学/计划结果仍需用户确认；AI 不直接删除/改写业务数据。

### 8.2 云端同步

- 当前没有云端账号/服务端/凭据。
- 实际可用：本地加密同步包（SAF 导出/导入），范围：任务、财务、词汇、知识、考试、长期目标。
- `SyncTransport`/`UnconfiguredCloudSyncTransport` 是未来适配接口；界面明确“未配置”，不会伪造成功。
- 课表、计时、习题明细、完整预算/偏好目前通过加密备份迁移，不走增量同步。

### 8.3 通知

- 使用 `POST_NOTIFICATIONS`；渠道：预算、计划、考试、睡前模式。
- 考试提醒每日一次；睡前模式只安排下一次；均为 WorkManager，可能受省电策略影响。
- 未使用 AlarmManager 精确闹钟；不控制系统免打扰。

## 9. 已知风险与建议优先级

### P0：先处理或明确标注

1. **同步对象身份**：当前按本地 ID 合并；不同设备各自新建对象可能 ID 碰撞。对多设备场景应改为全局 ID/映射表，或在 UI 明确“单主设备优先、实验性”。
2. **同步范围**：只覆盖 6 类数据；不要让用户误认为课表/计时/习题明细/完整设置也已同步。
3. **报告全量读取**：`ReportRepository.collectFacts()` 读取全部历史；多年数据可能 OOM/卡顿。应改为 SQL 聚合/分页/预聚合。
4. **数据库/备份安全**：普通 ZIP 未加密；加密备份口令丢失不可恢复；JSON 不支持反向导入。
5. **事务边界**：`ExerciseRepository` 内嵌套调用其他 Repository 的事务，需审计失败回滚范围。
6. **手工任务与睡眠**：手工保存可越过睡眠，仅提示；自动排程不会排入。产品需确认是否要强制阻断。

### P1：真机验收与体验

7. 桌面组件刷新频率、计时不是逐秒、深色/尺寸/启动器兼容。
8. 通知权限拒绝、延迟、重启恢复。
9. PDF 中文排版与分页。
10. 加密备份/恢复/彻底删除的大文件与中断场景。
11. 双设备同步包冲突、删除墓碑、ID 冲突。
12. 大字体/横屏/深色下新页面视觉。

### P2：算法与体验优化

13. 数学提示/证明检查的正确性提示与用户反馈闭环。
14. 知识图谱题目关联只按名称精确匹配；可增加别名/同义词。
15. 词汇导入无逐行预览；可补充。
16. 财务固定支出用分类预算合计近似；可加入真实固定账单。
17. 首页卡片排序目前为上下移动，可改拖拽。

## 10. 不要做的事

- 不要使用 `fallbackToDestructiveMigration` 或删除旧表；必须提供 Migration。
- 不要移除离线核心功能或把 AI 变成必需条件。
- 不要把财务流水、睡眠原始记录默认发送给 AI。
- 不要在没有云端服务时伪造“同步成功”。
- 不要在日志/异常/截图中输出 API Key 或备份口令。
- 不要让 AI 直接删除记录或绕过本地排程/睡眠约束。
- 不要只改 UI 而不接真实 Repository/Room 数据。

## 11. 重要测试与命令

```bat
set JAVA_HOME=D:\jdk17

rem 全量
gradlew.bat :app:testDebugUnitTest
gradlew.bat :app:lintDebug

rem 重点算法
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.sleep.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.vocabulary.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.knowledge.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.finance.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.report.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.history.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.ownership.*"
gradlew.bat :app:testDebugUnitTest --tests "com.zhixu.studyos.core.data.local.StudyOSDatabaseMigrationTest"

rem 构建
gradlew.bat :app:assembleDebug
gradlew.bat :app:assembleRelease
```

## 12. 文档索引

- `README.md`：功能、环境、完整手动验收清单、算法口径、已知限制。
- `docs/V2_RELEASE_NOTES.md`：V2.0 更新说明、功能状态、数据库升级、AI 配置、验证记录。
- `docs/V2_AUDIT_HANDOFF.md`：新增模块、关键逻辑、迁移、风险、优先审查代码、真机清单、性能瓶颈。
- `docs/ARCHITECTURE.md`：架构与模块边界（含 V2 增补）。
- `docs/DATABASE.md`：v9 表结构与迁移。
- `docs/CHANGELOG.md`：版本变更记录。
- `docs/INSTALL.md`：安装/升级/回退/权限。
- `docs/RELEASE.md`：签名与发布检查清单。

## 13. 交接确认清单

- [ ] 已能独立完成 Debug/Release 构建。
- [ ] 已跑通 497 项测试与 lint。
- [ ] 已在真机完成 V1.0→V2.0 覆盖升级并核对数据。
- [ ] 已验收四个桌面组件与四类通知。
- [ ] 已验证加密备份创建/预览/恢复与错误口令。
- [ ] 已验证 JSON 导出与彻底删除。
- [ ] 已用两台设备验证同步包冲突/删除。
- [ ] 已验收 PDF 中文排版。
- [ ] 已记录真机问题与修复优先级。
- [ ] 已离线备份签名密钥与 keystore 配置。
- [ ] 已确认下一阶段是否优先修复同步身份/范围与报告性能。

