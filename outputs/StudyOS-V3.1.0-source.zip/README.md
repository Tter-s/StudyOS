# 知序 StudyOS V3.1

只记录生活，不管理人生。

StudyOS 是一个完全离线的 Android 个人生活记录工具：每天写下明天要做的事、完成后打勾、晚上记下做了什么、睡了多久、娱乐了多久；财务和课表独立使用。没有账号、没有 AI、没有评分、没有排行榜。

## V3.1 保留的五项功能

1. **每日待办**：前一天晚上安排明天；今天逐条勾选；可添加、编辑、删除；未完成不会自动滚到第二天。
2. **每日总结**：记录当天实际做了什么；自动显示当天完成数 / 总数（例如 5/7）；可回看历史日期。
3. **财务记账**：收入、支出、退款，简单分类、金额、日期、备注；按月查看收入、支出与结余，可切换月份浏览。
4. **睡眠记录**：手动填写入睡和起床时间，自动计算时长；显示最近 7 天与全部记录。
5. **课程表**：保留原有周课表、学期设置、单双周、调课/停课、一次性日程与作息；课程可查看、添加、编辑、删除。

另外保留一个极简的**娱乐时间**记录：按“小时 + 分钟”手动填写，可回看；没有惩罚、评分或限制。

## 页面结构

底部导航固定五项：

```text
今日｜课表｜记录｜财务｜我的
```

- **今日**：今天的待办、完成进度、明日待办快捷入口。右下角 `+` 随时添加。
- **课表**：周课表；右上角菜单收纳学期设置、一次性日程、作息、调整记录和图片导入。
- **记录**：每日总结、睡眠记录、娱乐时间、历史记录四个入口；具体表单都在二级页面，历史按天汇总待办完成数、总结、睡眠与娱乐。
- **财务**：当月收入/支出/结余、最近账目、记一笔；左右切换月份。
- **我的**：主题（跟随系统/浅色/深色）、完整备份与导出/恢复、版本信息。

二级页面使用系统返回键或左上角返回，底部栏自动隐藏；返回后状态由 ViewModel 与 Room 保留。

## V3.1 不再出现在界面中的模块

AI 学习规划与 API 配置、学习计时与效率分析、科目分类体系、题库与刷题、自动排程、考试/长期目标、成就/积分/连续打卡、复杂统计与周报，均已从导航与界面移除。

这些模块的**历史数据没有被删除**，仍保存在原表中，并继续进入完整备份；旧任务会在升级时复制为 V3.1 的每日待办，便于在“历史记录”里回看。详细的数据依赖清单见 `docs/V3_1_RELEASE_NOTES.md`。

## 数据与隐私

- 完全离线：V3.1 不申请 `INTERNET` 权限（库清单合并的 INTERNET 也被显式移除）；课表、记录、财务、备份都在设备本地完成。
- 数据库 `studyos.db` 从 v9 升级到 v10：新增 `daily_tasks`、`daily_summaries`、`entertainment_records` 三张表；旧表原样保留。
- 升级不是破坏性的：迁移只新增表并复制旧任务，不删除旧数据。
- “我的 → 数据备份与导出”可创建包含全部业务表与旧归档数据的 ZIP 备份，也可从备份恢复；恢复旧版备份后会自动把其中的旧任务补进新的待办表。
- 备份不包含 AI 设置/API Key（V3.1 界面也不再提供）。

## 环境要求

- Android Studio Ladybug 或更新版本
- JDK 17
- Android SDK Platform 35；最低运行 Android 8.0（API 26）
- Gradle 8.9 Wrapper、AGP 8.7.3、Kotlin 2.0.21、Room 2.6.1、Compose BOM 2024.11.00

## 构建与测试

```bat
set JAVA_HOME=D:\jdk17
gradlew.bat :app:testDebugUnitTest
gradlew.bat :app:assembleDebug
gradlew.bat :app:assembleRelease
```

APK：

```text
app/build/outputs/apk/debug/app-debug.apk
app/build/outputs/apk/release/app-release.apk
```

安装：

```bat
adb install -r app\build\outputs\apk\debug\app-debug.apk
```

发布产物复制到 `outputs/StudyOS-V3.1.0-debug.apk` 与 `outputs/StudyOS-V3.1.0-release.apk`；源码归档为 `outputs/StudyOS-V3.1.0-source.zip`。Release 使用仓库根目录 `.signing/studyos-release.jks` 与 `keystore.properties` 签名。

## 工程结构（V3.1 主路径）

```text
app/src/main/java/com/zhixu/studyos/
├── core/data/
│   ├── local/DailyLogEntities.kt        # daily_tasks / daily_summaries / entertainment_records
│   ├── local/DailyLogDao.kt
│   ├── local/MigrationsV9To10.kt        # v9 → v10，非破坏性
│   ├── local/DailyLogBackfill.kt         # 旧任务 → V3.1 待办（升级/恢复旧备份）
│   └── repository/DailyLogRepository.kt
├── feature/today/                       # 今日、明日待办、编辑对话框
├── feature/records/                     # 记录中心、总结、睡眠、娱乐、历史
├── feature/finance/FinanceHomeScreen.kt # 简化财务首页（复用记账编辑对话框）
├── feature/profile/MineScreen.kt        # 主题 + 备份导出
├── navigation/                          # 五项底栏与二级路由
└── widget/                              # 今日待办、下一节课两个 Glance 组件
```

旧模块（`feature/study`、`feature/ai`、`feature/bank`、`feature/knowledge`、`feature/vocabulary`、`feature/math`、`feature/report`、`feature/exam`、`feature/sleep`、`feature/data` 等）仍保留源码与数据层，用于历史数据兼容与备份，但已不再挂载到导航。

## 已知限制（V3.1）

- 未连接真机/模拟器：桌面小组件、通知、图片导入、深层视觉与升级安装未做实机验收。
- 睡眠记录是手动填写，未接入可穿戴设备；日期按“起床当天”保存。
- 旧任务迁移到每日待办时，只取截止日期（没有截止日期则取最早学习时段日期）；同一天多个旧任务会保留为多条记录。
- 旧版备份恢复会在恢复事务内补齐待办表；若从 V3.1 备份恢复，则直接使用备份中的三张新表。
- 备份/恢复对话框仍保留旧模块的 CSV 导出入口（学习计时、习题记录），用于导出归档数据；这些功能不在 V3.1 主界面出现。
