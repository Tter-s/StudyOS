# AI 个人学习规划师（V0.9）

本文档是 V0.9 的数据流设计、接口定义、错误处理与测试方案。产品边界以 `版本更新工作/V0_9.md` 与 `V0_0.md` 为准。

## 1. 范围与不做什么

**已实现**

- 可选的 OpenAI 兼容 AI 接口：默认服务地址/模型为 DeepSeek（`https://api.deepseek.com/v1`、`deepseek-chat`），用户可改为其他地址/模型；API Key 使用 Android Keystore 加密保存；Token 与费用估算；每日调用次数与费用上限；手动触发；缓存；离线错误提示。
- 学习数据聚合：过去七天学习分钟数（按科目/按天）、任务完成与安排数量、完成率、未来任务（含延期次数）、困难习题信号、学习目标与排程设置。
- 结构化计划：总结、科目每日时间分配、任务用时估计、休息提醒、下一周建议、风险提示。
- 严格的 JSON Schema 校验 + 本地约束检查 + 预览 + 用户确认后才应用（仅写入任务预计用时与建议记录）。
- 隐私控制：默认不发送困难题目细节；可关闭科目名称与任务标题；**从不发送财务数据**；调用前可展开查看完整发送内容。

**未实现（不提供假按钮）**

- 非 OpenAI 兼容的服务适配。`AiProvider` 是独立接口，接入其他服务只需新增实现，不修改规划流程。
- 自动/后台调用 AI。V0.9 只有用户手动触发；没有 WorkManager 定时 AI 任务。
- 把 AI 科目分配直接写入排程偏好：科目分配只作为建议与记录保存，实际排程仍由本地 AutoScheduler 依据用户设置运行。
- AI 生成题目解答、修改题干或写入题库。
- 精确账单：费用是按用户填写单价与返回 token 数的估算。

## 2. 数据流

```text
学习中心 / 任务 / 排程 / 题库（本地 Room + DataStore）
  → LocalAiStudyDataSource（仅学习数据，排除财务）
  → AiSnapshotBuilder → AiStudySnapshot → toJson（按隐私开关掩码/裁剪）
  → AiPromptBuilder（系统提示词含 JSON Schema 与数值约束）
  → [用户点击「生成 AI 建议」]
  → 额度检查（每日次数 / 每日费用）→ 网络检查
  → 缓存检查（模型 + 提示词版本 + 数据快照的 SHA-256；24 小时内命中即复用）
  → OpenAiCompatibleProvider → AiHttpTransport(HttpURLConnection)
  → 记录 token 与估算费用（即使随后解析失败也记录）
  → AiPlanParser（JSON Schema 校验）
  → AiPlanConstraintChecker（本地约束）
  → 预览（可勾选任务用时）→ 用户确认
  → 本地写入：任务预计用时（仅勾选且仍合法的项）+ ai_plan_records 建议记录
```

AI 永远不会直接写数据库。服务层写入的只有 `ai_usage_daily`（用量）、`ai_analysis_cache`（缓存）与 `ai_plan_records`（用户确认后的建议记录）；任务修改由 ViewModel 在用户确认后通过既有 `TaskRepository` 执行。

## 3. 接口定义

### 3.1 AIProvider

```kotlin
interface AiProvider {
    val providerName: String
    suspend fun complete(request: AiCompletionRequest): AiProviderResult
}

data class AiCompletionRequest(
    val systemPrompt: String,
    val userPrompt: String,
    val maxOutputTokens: Int = 1500,
)

data class AiProviderResult(
    val content: String,
    val promptTokens: Int,
    val completionTokens: Int,
    val model: String,
    val latencyMillis: Long,
    val tokensEstimated: Boolean = false,
)
```

`OpenAiCompatibleProvider` 使用 `POST {baseUrl}/chat/completions`，请求体 `model/messages/temperature/max_tokens/response_format`；服务端不支持 `response_format`（400 且错误信息提到它）时自动去掉该字段重试一次。

### 3.2 抽象与实现

| 接口 | 实现 | 职责 |
| --- | --- | --- |
| `AiProvider` | `OpenAiCompatibleProvider` | 一次聊天补全 |
| `AiHttpTransport` | `UrlConnectionAiHttpTransport` | JSON POST、超时、网络错误映射 |
| `AiPlanCoordinator` | `AiPlanningService` | 缓存/限额/离线检查、调用、校验、记录 |
| `AiStudyDataSource` | `LocalAiStudyDataSource` | 聚合本地学习数据 |
| `AiConfigStore` | `AiSettingsRepository`（DataStore） | 非敏感配置（地址/模型/超时/价格/额度/隐私开关） |
| `ApiKeyStore` | `KeystoreApiKeyStore` | 密钥加密存取 |
| `AiRepository` | `OfflineAiRepository`（Room） | 用量、缓存、建议记录 |
| `AiConnectivity` | `AndroidAiConnectivity` | 网络可用性 |

排除在设计之外但沿用：`TaskRepository`（应用确认后的用时）、`SchedulingRepository`（读取每日上限）、`LearningRepository`/`ProblemBankRepository`（只读快照）。

### 3.3 计划 JSON Schema（版本 1）

```json
{
  "schemaVersion": 1,
  "summary": "string（≤2000 字）",
  "subjectAllocations": [
    {"subject": "必须来自本地科目", "minutesPerDay": "0..每日上限", "reason": "string"}
  ],
  "taskEstimates": [
    {"taskId": "必须来自 upcomingTasks", "estimatedMinutes": "5..300", "reason": "string"}
  ],
  "restReminders": ["string"],
  "weeklySuggestions": ["string"],
  "riskFlags": [{"kind": "string", "detail": "string"}]
}
```

数量上限：科目分配 10、任务估计 15、休息提醒 5、周建议 5、风险提示 5。未知字段忽略；代码围栏与前后说明文字会被剥离。

### 3.4 本地约束检查

| 规则 | 结果 |
| --- | --- |
| taskId 不在本次发送的未来任务中 | 拒绝该项 |
| 同一 taskId 出现多次 | 保留第一条，其余拒绝 |
| estimatedMinutes ∉ 5..300 | 拒绝该项 |
| 科目名不在本地科目中 | 拒绝该项 |
| minutesPerDay > 每日学习上限或分配合计超限 | 拒绝该项 |
| 科目名称使用掩码（隐私关闭） | 拒绝全部科目分配（无法映射） |
| 没有任何可执行项 | 警告（仅文字建议） |

被拒绝项在预览中可见并附原因；用户可继续确认其余合法项。

## 4. 错误处理

| 场景 | 分类 | 用户可见文案（要点） | 是否重试 |
| --- | --- | --- | --- |
| 未启用 | `DISABLED` | 请先在「我的 → AI 设置」开启 | 否 |
| 未配置地址/模型/Key | `NOT_CONFIGURED` | 补全配置 | 否 |
| 离线 | `OFFLINE` | 本地功能不受影响，联网后重试 | 否 |
| 达到每日调用次数 | `DAILY_CALL_LIMIT` | 明天再试或调整上限 | 否 |
| 达到每日费用上限 | `DAILY_COST_LIMIT` | 显示当前上限 | 否 |
| HTTP 401/403 | `UNAUTHORIZED` | 更新 API Key（不回显密钥） | 否 |
| HTTP 404 | `NOT_FOUND` | 检查地址与模型 | 否 |
| HTTP 429 | `RATE_LIMITED` | 稍后重试 | 是 |
| HTTP 400/422 | `REQUEST_REJECTED` | 检查模型名称与参数 | 否 |
| HTTP 5xx | `SERVER_ERROR` | 稍后重试 | 是 |
| 超时 / 网络 | `TIMEOUT` / `NETWORK` | 检查网络与服务地址 | 是 |
| 响应非 JSON / 缺 choices | `INVALID_RESPONSE` | 服务返回格式异常 | 是 |
| 不符合 Schema | `SCHEMA_INVALID` | 列出前几项结构错误 | 是（重新生成） |

失败时的用量：只要接口返回了 200，token 用量与估算费用都会记录（即使 Schema 校验失败），避免费用“消失”；网络失败无法得知 token，则不记录。

## 5. 成本控制

1. 默认 `enabled=false`，且没有自动调用路径；只有「生成 AI 建议」按钮触发。
2. 相同输入（模型 + 提示词版本 + 数据 JSON 的 SHA-256）在 24 小时内命中缓存，直接提供「使用缓存结果」，不调用接口。
3. 数据或模型变化会产生新的缓存键；界面据此清空旧预览，避免应用过期建议。
4. 每日调用次数与每日估算费用上限在调用前检查；额度用尽后按钮仍可点击但会给出明确错误。
5. 缓存 7 天后清理；用量按自然日（本地时区）持久化在 `ai_usage_daily`。
6. 费用 = token 数 × 用户填写单价（每百万 token 微元价），四舍五入到微元；服务端未返回 usage 时按输出字符数/4 估算并标注。
7. 测试连接也会计入用量（按钮上明确标注「会产生费用」）。

## 6. 隐私

- 发送前显示数据摘要，并可展开完整 JSON 预览与字节数。
- 财务数据从不进入快照；测试断言 JSON 不含 finance/budget/amount/transaction 字段。
- 默认：发送科目名称与任务标题；**不发送**困难题目的题号/章节/知识点，只发送按科目的数量摘要。
- 可关闭科目名称（掩码为「科目1…」）与任务标题（「任务 #id」）；关闭科目名称时科目分配建议会被本地约束拒绝。
- API Key 使用 Android Keystore AES-256-GCM 加密；`shared_prefs` 不在备份规则内，不会进入云备份/设备迁移；错误信息与日志都不包含密钥。
- 只有 AI 功能需要 `INTERNET` 权限；课表导入、题库 OCR、公式预览等仍然完全离线。

## 7. 测试方案与实际覆盖

纯 JVM 测试（`app/src/test/.../core/ai`）：

- 成本：单价换算、四舍五入、零价、负 token、格式化。
- 哈希：相同输入稳定、模型/数据/提示词版本变化换键。
- 配置校验：协议、超时、额度、价格、启用但缺地址。
- 快照：七天窗口、进行中会话排除、完成率、未来任务与延期次数、困难题信号。
- 提示词/隐私：掩码、标题隐藏、题目明细开关、确定性、无财务字段、Schema 文本。
- Schema：合法计划、代码围栏、缺字段、类型错误、越界、版本不符、超量、未知字段、空数组、空字符串。
- 本地约束：未知任务/科目、重复任务、边界分钟、分配合计超限、掩码模式、无可执行项警告。
- 网络：成功解析、请求体/鉴权头、地址拼接、401/404/429/5xx/400、`response_format` 重试、非 JSON、空 choices、无 usage 估算、空密钥不发请求。
- 规划服务（假仓库/假传输）：成功记账与缓存、缓存命中不再调用、强制刷新、未启用/未配置/离线/次数上限/费用上限、Schema 失败仍记账、未知 taskId 被拒绝、缓存使用、确认记录、测试连接。
- 仓库（内存 Room）：用量累加、缓存有效期与清理、建议记录排序。
- ViewModel（假数据源/假协调器/假任务仓库）：初始化快照与预览、生成后选中全部可应用项、只应用勾选项、不勾选时仅保存、数据变化清空旧预览、隐私开关持久化、离线错误映射、缓存结果标记。
- Compose 冒烟：未配置提示且不触发生成、已配置显示生成、预览展示与确认回调、隐私开关回调、错误提示与关闭。
- 设置换算：元 ↔ 微元（含四舍五入与非法输入）。
- 迁移：v6 → v8 链式迁移，保留任务/课表/题库数据，`postponeCount` 默认 0，AI 用量表可用。

真机验收（本轮未执行）：真实服务调用、Keystore 加密存储、系统备份不含密钥、网络切换/超时、深色主题布局。

## 8. 手动验收清单

1. 「我的 → AI 设置」填写地址/模型/价格/额度，保存密钥；重启应用后仍显示已保存（无需重新输入）。
2. 在「学习 → AI 规划」确认发送内容预览，切换隐私开关观察 JSON 变化。
3. 点击生成：观察今日调用次数与估算费用增加；再次点击同一数据应提示缓存并提供「使用缓存结果」。
4. 校验失败/离线/无效 Key 时错误提示明确，且本地课表、任务、题库功能不受影响。
5. 预览中取消勾选部分任务，确认后只有勾选项的预计用时改变；「学习 → 排程」重新生成使用新的预计时间。
6. 升级安装（0.8.0 → 0.9.0）保留全部数据。
