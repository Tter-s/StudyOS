# 发布与签名说明（维护者）

## 1. 签名材料位置

| 文件 | 内容 | 是否纳入版本控制 |
| --- | --- | --- |
| `.signing/studyos-release.jks` | RSA 4096 位 Release 密钥（有效期 10,000 天） | **否**（`.gitignore` 已排除） |
| `keystore.properties` | 上述密钥的路径、别名与密码 | **否**（`.gitignore` 已排除） |

- 两个文件仅存在于本机项目根目录，不会被写入 APK、备份或日志。
- 已尝试用 `icacls` 将权限限制为当前 Windows 用户；该操作依赖本机账户名（本例为 `TTER\Tter`）。迁移到其他机器时需重新设置。
- **必须离线备份**这两个文件（例如加密 U 盘/密码管理器）。密钥丢失将无法发布同签名升级包，用户只能卸载重装并依赖完整备份恢复。
- 不要通过聊天、邮件、截图或 Git 传递 `keystore.properties`。如果不慎泄露，请生成新密钥（用户需要卸载重装并使用完整备份）。

## 2. 构建正式 APK

```bash
# Windows PowerShell / Git Bash，JDK 17+（本机为 21）
export JAVA_HOME="/c/Users/<user>/.workbuddy/binaries/jdk/jdk-21.0.12.1+1"
./gradlew :app:testDebugUnitTest :app:lintDebug
./gradlew :app:assembleRelease
cp app/build/outputs/apk/release/app-release.apk outputs/StudyOS-V3.0.0-release.apk
```

验证签名与清单：

```bash
$ANDROID_SDK/build-tools/35.0.0/apksigner.bat verify --print-certs outputs/StudyOS-V3.0.0-release.apk
$ANDROID_SDK/build-tools/35.0.0/aapt2.exe dump permissions outputs/StudyOS-V3.0.0-release.apk
```

当 `keystore.properties` 不存在时，Gradle 仍可构建 **未签名** 的 release APK（仅用于本地检查），但不得分发。

## 3. 版本规则

- `versionCode` 每次发布 +1（V1.0.0 = 10，V2.0.0 = 20，V3.0.0 = 30）。
- `versionName` 使用语义化版本；数据库版本独立管理（V1.0.0 = 8，V2.0.0 = 9，V3.0.0 仍为 9）。
- 任何数据库 Schema 变更必须新增 `Migration` 并导出 Schema JSON，禁止 destructive migration。

## 4. V3.0 额外检查

- 确认 Release APK 的 `versionName=3.0.0`、`versionCode=30`，并使用 `apksigner verify --verbose` 确认 v3 签名方案为 true。
- 确认 AI 设置默认展示 `https://api.deepseek.com/v1` 与 `deepseek-chat`，但 AI 仍默认关闭且不内置 API Key。
- 确认 `.restore_journal` 中断恢复与报告窗口化逻辑在真机/模拟器上可用。

- 确认四个组件 Receiver 在合并后的 Manifest 中存在：`TodayTasksWidgetReceiver`、`NextClassWidgetReceiver`、`StudyTimerWidgetReceiver`、`TodayOverviewWidgetReceiver`。
- 确认 `POST_NOTIFICATIONS` 仍为唯一通知权限；`INTERNET` 仅用于用户主动 AI。
- 确认数据库 Schema 9 已导出，`MIGRATION_8_9` 覆盖旧表列与新表；旧备份恢复兼容测试通过。
- 在真机添加/调整四个组件，检查深浅色、空状态与点击跳转。
- 检查考试提醒与睡前模式通知、权限拒绝、WorkManager 延迟、重启恢复。
- 检查加密备份恢复、JSON 导出、彻底删除与同步包冲突界面。
- 发布包应使用现有 Release 密钥；Debug/Release 签名不同，不能互相覆盖。

## 5. 发布检查清单

1. 全量单测通过（`testDebugUnitTest`），迁移与备份测试包含在内。
2. `lintDebug` 0 errors。
3. `assembleDebug` 与 `assembleRelease` 均成功。
4. `apksigner verify` 通过；`aapt2 dump permissions` 无新增敏感权限。
5. 复制 APK 到 `outputs/` 并保留上一稳定版本。
6. 更新 `docs/CHANGELOG.md`、`README.md` 验证记录、`docs/QA_REPORT.md`。
7. 在真实设备执行 `docs/QA_REPORT.md` 的「需真机执行」清单。
