# 知序 StudyOS V3.0.0 更新说明

更新日期：2026-10-26

版本：`3.0.0`（versionCode 30），数据库 v9（Schema 未变更）。

## 一、本次重点

1. **默认 AI 接入 DeepSeek**：
   - 默认服务地址：`https://api.deepseek.com/v1`
   - 默认模型：`deepseek-chat`
   - AI 仍默认关闭，API Key 必须由用户自行填写并通过 Android Keystore 保存；不存在内置密钥。
2. **AI 额度并发保护**：新增 `AiRequestGate`，规划服务与统一 AI 任务服务共用一把进程内互斥锁，额度检查、调用和记账串行执行。
3. **恢复哨兵**：恢复前写 `.restore_journal`，并在数据库事务内写入 `sync_state` 哨兵；启动时据此判断继续替换文件还是回滚，消除“数据库提交后、日志写入前”的中断窗口。
4. **报告窗口化**：周报只读取本周明细，成长读取最近 24 个月；仅在确有对应尝试时加载题库/手工题映射，降低长期数据的内存压力。
5. **签名**：使用项目 Release 密钥签名，显式启用 APK Signature Scheme v3；APK 的 versionName 为 `3.0.0`、versionCode 为 30。

## 二、继承自 V2.0 的功能

V2.0 的睡眠保护、任务历史、数据所有权、四类桌面组件、词汇/SM-2、知识图谱、周报/成长、数学分级提示、习题难度匹配、财务预测、考试与长期目标、加密备份和本地同步全部保留；数据库仍为 v9，升级不需要数据迁移。

## 三、验证

- `:app:testDebugUnitTest`：497 项，0 失败、0 跳过。
- `:app:lintDebug`：0 errors、40 warnings。
- `:app:assembleDebug` / `:app:assembleRelease`：成功。
- `apksigner verify`：Release APK 通过，包含 v2/v3 签名方案（v3=true；minSdk 26 不需要 v1/JAR 签名）。
- 未连接真机；桌面组件、通知、PDF、恢复中断和双设备同步仍需真机验收。

## 四、产物

- `outputs/StudyOS-V3.0.0-debug.apk`
- `outputs/StudyOS-V3.0.0-release.apk`
- 回退产物：`outputs/StudyOS-V2.0.0-*.apk`、`outputs/StudyOS-V1.0.0-*.apk`
