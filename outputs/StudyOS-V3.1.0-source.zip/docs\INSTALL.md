# 安装、升级与回退

## 1. 构建产物

| 文件 | 用途 | 签名 |
| --- | --- | --- |
| `outputs/StudyOS-V3.0.0-release.apk` | V3.0 正式发布版（推荐日常使用） | 项目 Release 密钥（`.signing/studyos-release.jks`） |
| `outputs/StudyOS-V3.0.0-debug.apk` | V3.0 调试版 | Android Debug 证书 |
| `outputs/StudyOS-V2.0.0-*.apk` / `V1.0.0-*.apk` | V2.0 / V1.0 回退版本 | 对应密钥 |

两个 APK 的包名相同（`com.zhixu.studyos`）但签名不同，**不能相互覆盖安装**。

## 2. 全新安装

1. 将 APK 传到手机（USB、网盘或 `adb install`）。
2. 允许「安装未知来源应用」（系统会按应用来源询问）。
3. 安装并打开「知序 StudyOS」。
4. 首次使用建议先到「我的 → 数据备份与导出」创建一份备份。

命令行：

```bash
adb install -r outputs/StudyOS-V3.0.0-release.apk
```

## 2.0.1 从 V2.0.0 升级到 V3.0.0

- 同签名（Release→Release 或 Debug→Debug）可直接覆盖安装；数据库仍为 v9，不需要迁移，V2.0 的数据与 AI/同步设置保留。
- V3.0 默认 AI 服务地址/模型为 DeepSeek，但 AI 仍默认关闭，API Key 需要重新确认；旧配置不会被覆盖。
- V3.0 的 Release APK 使用 APK Signature Scheme v3 签名，可用 `apksigner verify --verbose` 检查。

## 2.1 从 V1.0.0 升级到 V2.0.0

- 同签名的 V1.0 Release → V2.0 Release（或 Debug → Debug）可直接覆盖安装；数据库自动执行 v8→v9 迁移，任务、课程、学习、财务、题库与 AI 表保留，任务会回填 `globalId`。
- 升级前建议在 V1.0 创建完整备份；升级后可在 V2.0「我的 → 数据与同步」创建加密备份/JSON 导出。
- V2.0 新增桌面小组件：安装后长按桌面 → 小组件 → 知序 StudyOS，添加今日任务/下一节课/学习计时/今日概览。
- 新增权限仅使用既有 `POST_NOTIFICATIONS`：考试提醒（每日一次）与睡前模式使用本地 WorkManager，非精确闹钟。
- 从 V2.0 回退到 V1.0：V1.0 不认识 v9 数据库；需卸载 V2.0、安装 V1.0，并恢复 V1.0 之前创建的备份。V2.0 的加密备份无法在 V1.0 中读取。

## 3. 从 V0.9.0（Debug）升级到 V1.0.0（Release）

Debug 与 Release 签名不同，系统不允许直接覆盖。推荐使用 V1.0 新增的完整备份：

1. 在旧版（0.9.0）打开「我的 → 数据备份与导出 → 创建完整备份」，保存 ZIP。
2. 卸载旧版（会删除应用数据，但备份 ZIP 在外部存储中不受影响）。
3. 安装 `StudyOS-V1.0.0-release.apk`。
4. 打开「我的 → 数据备份与导出 → 从备份恢复」，选择刚才的 ZIP。
5. 阅读预览中的行数、文件数与警告，确认后恢复。
6. 恢复会替换全部业务数据并恢复题库原始文件；AI 设置与 API Key 不包含在备份中，需要重新填写。

如果只想继续使用调试版，可直接安装 `StudyOS-V1.0.0-debug.apk` 覆盖 0.9.0（同签名），数据自动保留并执行数据库迁移。

## 4. 从更早版本（V0.1–V0.8 Debug）升级

同一 Debug 证书的版本可直接安装覆盖，数据库会按 `MIGRATION_1_2 … MIGRATION_7_8` 顺序升级，既有数据保留。跨过 V1.0 后如需回退到 0.9.0：

1. 在 V1.0 创建完整备份。
2. 卸载 V1.0。
3. 安装 `StudyOS-V0.9.0-debug.apk`。

**注意**：0.9.0 不认识 V1.0 的数据库/v8 之后的备份格式，不能直接把 V1.0 备份恢复到 0.9.0。回退后只能使用 0.9.0 之前创建的备份；因此升级前先保留一份旧版的完整备份最稳妥。

## 5. 回退版本

- `outputs/StudyOS-V0.9.0-debug.apk` 保留为上一个稳定可回退版本。
- V1.0 Release 与 Debug 均保留在 `outputs/`。
- 回退前请导出重要数据（任务/学习记录/财务 CSV 或完整备份），因为卸载会清除应用私有目录。

## 6. 权限说明

| 权限 | 用途 |
| --- | --- |
| `POST_NOTIFICATIONS` | 可选的预算/计划/考试提醒与睡前模式通知（需用户开启并授权） |
| `INTERNET` | 仅在用户主动配置并点击「生成 AI 建议 / 测试连接」时使用 |
| `ACCESS_NETWORK_STATE` | 判断 AI 请求前是否离线 |
| `WAKE_LOCK` / `RECEIVE_BOOT_COMPLETED` / `FOREGROUND_SERVICE` | WorkManager 提醒、桌面组件兜底刷新（应用没有自建前台服务；学习计时退到后台自动暂停） |

应用**不申请**存储权限：备份/导出通过系统文件选择器（SAF）读写用户选择的位置；课表/题库选图使用系统 Photo Picker。
