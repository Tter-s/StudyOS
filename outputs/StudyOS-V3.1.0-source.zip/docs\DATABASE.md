
## V3.1 极简生活记录（数据库 v10）

V3.1 在保留全部旧表的前提下新增三张表；旧表不再有界面入口，但继续进入备份。

### daily_tasks

每日待办，只有日期、标题、完成状态与排序。

- `id`（自增主键）、`dateEpochDay`（所属日期，索引）、`title`
- `isCompleted`（0/1）、`completedAtEpochMillis`（完成时间，未完成时为空）
- `sortOrder`、`createdAtEpochMillis`、`updatedAtEpochMillis`

### daily_summaries

每天一条的总结。

- `dateEpochDay`（主键）、`content`（最多 2000 字）
- `createdAtEpochMillis`、`updatedAtEpochMillis`

### entertainment_records

每天一条的娱乐时间。

- `dateEpochDay`（主键）、`minutes`（0–1440）
- `createdAtEpochMillis`、`updatedAtEpochMillis`

### 迁移与回填

- `MIGRATION_9_10` 创建三表与索引，并从 `study_tasks` 复制旧任务：
  `COALESCE(dueDateEpochDay, MIN(task_sessions.dateEpochDay))` 作为日期，保留标题、完成状态/时间、排序与时间戳。
- 迁移不删除、不改写旧表；旧表继续用于归档与备份。
- 恢复 `databaseVersion < 10` 的旧备份时，恢复事务内调用同一段回填逻辑；V3.1 备份直接包含三张新表。
- 备份表清单新增 `daily_tasks`、`daily_summaries`、`entertainment_records`；旧备份缺失时按空表处理。

## V0.8 个人题库表

### problem_documents

导入来源文档（原始文件已复制到 `filesDir/problem_bank_documents/`）。

- `id`、`displayName`、`type`（`PDF`/`IMAGES`）、`relativePath`（应用私有目录内相对路径）
- `originalName`、`sizeBytes`、`contentSha256`（内容查重）、`pageCount`
- `createdAtEpochMillis`、`updatedAtEpochMillis`

### problem_document_pages

每页持久化的最佳可用文本（内嵌文本优先，缺失时为 OCR 结果）。

- `documentId`（FK CASCADE）、`pageIndex`（同文档唯一）、`text`、`textSource`（`EMBEDDED`/`OCR`/`NONE`）

### problem_import_batches / problem_import_items

批次与逐页处理状态，支持取消、恢复与失败重试。

- 批次：`documentId`（FK CASCADE）、`status`（`RUNNING`/`PAUSED`/`COMPLETED`/`ABORTED`）、`totalPages`
- 条目：`batchId`（FK CASCADE）、`pageIndex`（同批次唯一）、`status`（`PENDING`/`RUNNING`/`DONE`/`FAILED`/`SKIPPED`）、`attempts`、`lastError`、`draftJson`（该页全部草稿，版本化 JSON）

### problem_bank_entries

题目主表，对应 V0.8 第二节的题目结构。

- `documentId`（FK **RESTRICT**：仍有题目时禁止删除来源）、`pageIndex`
- `courseId`（FK SET NULL 到 `courses`）、`courseName`、`textbook`、`chapter`、`problemNumber`、`statement`
- `estimatedDifficulty`（1–5，可空）、`difficultySource`（`HEURISTIC`/`USER`）、`estimatedMinutes`、`actualMinutes`
- `completionStatus`（`NEW`/`IN_PROGRESS`/`COMPLETED`）、`reviewStatus`（`NOT_STARTED`/`REVIEWING`/`MASTERED`）
- `learningSuggestion`、`suggestionSource`、`dependsOn`（换行分隔题号）、`importBatchId`
- 唯一索引 `(documentId, chapter, problemNumber)` 实现同来源+章节+题号去重的数据库兜底。

### problem_bank_formulas / problem_bank_knowledge_points

题目的公式与知识点明细，级联删除。

- 公式：`problemId`、`orderIndex`（同题目唯一）、`latex`、`confidence`、`needsReview`、`originalSnippet`
- 知识点：`problemId`、`name`（同题目唯一）、`source`（`HEURISTIC`/`USER`）

### 迁移

- `MIGRATION_6_7`：创建上述七张表与全部索引，不修改既有表；`1→7` 全链路迁移测试覆盖旧数据保留与新表可用性。

## V0.9 AI 规划表

### study_tasks.postponeCount

- 新增列 `postponeCount INTEGER NOT NULL DEFAULT 0`，由「延期」操作累加。
- 参与排程评分（既有 `TaskScoring` 可继续读取）与 AI 数据快照中的「经常延期的任务」信号。
- 迁移：`MIGRATION_7_8` 使用默认值 0，旧数据不受影响。

### ai_usage_daily

按自然日统计 AI 调用量，用于每日次数与费用上限。

- `dateKey`（`YYYY-MM-DD`，主键）、`requestCount`、`promptTokens`、`completionTokens`
- `estimatedCostMicros`（微元，整数）、`updatedAtEpochMillis`

### ai_analysis_cache

按「提示词版本 + 模型 + 数据快照 SHA-256」缓存一次分析结果。

- `cacheKey`（主键）、`model`、`planJson`（校验前的结构化计划 JSON）
- `promptTokens`、`completionTokens`、`costMicros`
- `createdAtEpochMillis`；读取时限制 24 小时有效，7 天后清理

### ai_plan_records

用户在预览中确认后保存的建议记录（不直接改业务数据）。

- `createdAtEpochMillis`、`model`、`usedCache`
- `planJson`、`appliedTaskCount`（实际应用的任务用时数量）、`costMicros`

### 迁移

- `MIGRATION_7_8`：为 `study_tasks` 增加延期计数并创建上述三张 AI 表。
- 迁移测试覆盖 v6 → v8 链式升级：既有任务/课表/题库数据保留，延期计数默认 0，AI 表可读写。

## V1.0 数据库审计与备份策略

### 审计结论

- 共 28 张表：25 张业务表 + 3 张 AI 表；所有多表写入路径均在 `database.withTransaction { }` 内完成（任务/会话、学习计时、排课导入、排程保存、预算、题库入库与编辑、AI 用量）。
- 外键：任务会话 CASCADE、课程例外 CASCADE、学习计时对科目 RESTRICT / 任务 SET NULL、财务分类 RESTRICT、题库来源 RESTRICT / 课程 SET NULL、题库明细 CASCADE。
- 索引覆盖常用查询：任务状态/系列/截止日、会话任务与日期、计时科目/任务/状态/日期、财务日期/分类/类型、财务预算分类、题库 (来源,章节,题号) 唯一索引、完成/复习状态、课程设置；V1.0 分页查询复用 `(documentId, chapter, problemNumber)` 等现有索引前缀。
- 生产代码中 `allowMainThreadQueries` 与 `fallbackToDestructiveMigration` 出现次数为 **0**；所有读写通过 suspend DAO 或 Flow，Room 默认禁止主线程查询。
- 迁移链：`MIGRATION_1_2 → 2_3 → 3_4 → 4_5 → 5_6 → 6_7 → 7_8`，Schema JSON 覆盖 v1–v8；测试 `migration1To8`、`migration2To8`、`migration6To8` 从原始旧库结构升级并断言旧数据保留、新表可用。

### 备份/恢复数据范围

- **包含**：25 张业务表的全部列 + `problem_documents` 引用的题库原始文件（PDF/图片，保持相对路径）。
- **不包含**：`ai_usage_daily`、`ai_analysis_cache`、`ai_plan_records`、DataStore 偏好、Android Keystore 中的 AI API Key、应用代码与缓存。
- 备份 ZIP 结构：`manifest.json`（格式 v1、数据库版本、应用版本、创建时间、时区、各表行数、文件数量/总大小、排除项）、`data.json`（SQL 级 JSON 快照）、`documents/…`。
- 恢复前必须通过只读校验并展示预览；恢复在事务内执行并核对行数，失败回滚数据库；数据库提交后再替换文件，中断由 `.restore_journal` 续做。

### 导出（非恢复格式）

`docs/INSTALL.md` 与「我的 → 数据备份与导出」提供任务、学习计时、习题记录、财务流水 CSV。CSV 带 UTF-8 BOM、RFC 4180 引号与 CRLF，仅用于查看/分析，不能用于恢复。


## V2.0 数据库 v9

### 旧表变更

- `study_tasks`：新增 `globalId TEXT NOT NULL DEFAULT ''`（迁移回填 `task-<id>`）、`revision INTEGER NOT NULL DEFAULT 1`、`sourceType TEXT NOT NULL DEFAULT 'USER'`、`sourceId TEXT`；新增非唯一索引 `globalId`。任务事件和同步以这些字段追溯来源与版本。
- `finance_transactions`：新增 `revision INTEGER NOT NULL DEFAULT 1`、`isExpectedExpense INTEGER NOT NULL DEFAULT 0`（用户标记的正常特殊开支，异常检测跳过）。

### 新增表（27 张）

- 历史：`task_events`（对象类型/ID、事件类型、时间、前后 JSON、来源、原因、会话、修订）。
- 睡眠：`sleep_schedule`（工作日/周末/考试周作息、边界、缓冲、午休、睡前模式）、`sleep_date_overrides`、`sleep_records`、`sleep_change_history`。
- 词汇：`vocabulary_words`（normalizedWord 唯一、状态、SM-2 字段、due）、`vocabulary_reviews`、`vocabulary_settings`。
- 知识图谱：`knowledge_nodes`（subject+name 唯一、掌握度、笔记）、`knowledge_dependencies`（from 前置 → to 后续，唯一、级联）、`knowledge_problem_links`。
- 考试/目标：`exams`、`long_term_goals`、`goal_milestones`（级联）。
- 习题学习：`exercise_attempts`、`exercise_hint_records`、`exercise_profiles`、`exercise_saved_proofs`、`exercise_error_reports`、`ability_estimates`。
- AI/报告：`ai_analysis_records`、`weekly_reports`（weekStart 唯一）。
- 同步：`sync_operations`、`sync_baselines`、`sync_tombstones`、`sync_state`。
- 首页：`home_card_preferences`。

### 迁移与触发器

- `MIGRATION_8_9` 只新增表和带默认值列；在单事务内回填 `globalId`、创建全部索引与触发器。
- `SyncTriggers` 为任务/财务/词汇/知识/考试/长期目标安装 INSERT/UPDATE/DELETE 触发器；删除记录写入墓碑。新建数据库与迁移都安装。
- 备份恢复时临时移除/重建 `globalId` 索引，恢复后清空同步队列/基线/墓碑。
- Schema 导出：`app/schemas/.../9.json`。测试覆盖 v1/v2/v6→v9。
